package jump2java;

public class Sample0305_01 {
	public static void main(String[]args) {
		
		StringBuilder sb = new StringBuilder();
		sb.append("hello");
		sb.append(" ");
		sb.append("jump to java");
		String result = sb.toString();
		System.out.println(result);
		
	}
	
}
